public class ClothingException extends Exception {
    public ClothingException(String s) {
        super(s);
    }
}
