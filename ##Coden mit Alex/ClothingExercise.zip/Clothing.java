import java.util.Objects;

public abstract class Clothing {
    private Colour colour;
    private int size;
    private Textile textile;

    public Clothing(Colour colour, int size, Textile textile) throws ClothingException {
        this.colour = colour;
        this.setSize(size);
        this.textile = textile;
    }

    public Clothing() throws ClothingException {
        this(Colour.COLOUR_WHITE, 5, Textile.TEXTILE_COTTON);
    }

    public Colour getColour() {
        return colour;
    }

    public void setColour(Colour colour) {
        this.colour = colour;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) throws ClothingException {
        // Assumption: Sizes are valid from 1-10
        if (size < 1 || size > 10) {
            throw new ClothingException("Valid sizes: 1-10");
        }
        this.size = size;
    }

    public Textile getTextile() {
        return textile;
    }

    public void setTextile(Textile textile) {
        this.textile = textile;
    }

    public abstract Sleeves getSleeves();

    public abstract void setSleeves(Sleeves sleeves);

    @Override
    public String toString() {
        return super.toString() + "\nClothing{" +
                "colour=" + colour +
                ", size=" + size +
                ", textile=" + textile +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Clothing)) return false;
        Clothing clothing = (Clothing) o;
        return getSize() == clothing.getSize() && getColour() == clothing.getColour() && getTextile() == clothing.getTextile();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getColour(), getSize(), getTextile());
    }
}
