public enum Textile {
    TEXTILE_COTTON,
    TEXTILE_ELASTIC,
    TEXTILE_LATEX
}
