import java.util.ArrayList;
import java.util.Objects;

public class TShirt extends Clothing {
    private Sleeves sleeves;
    private ArrayList<String> careInfo;
    private String info;

    public TShirt(Colour colour, int size, Textile textile, Sleeves sleeves) throws ClothingException {
        super(colour, size, textile);
        this.sleeves = sleeves;
        this.careInfo = new ArrayList<>();
        this.info = "";
    }

    public TShirt(Sleeves sleeves) throws ClothingException {
        super();
        this.sleeves = sleeves;
    }

    public TShirt() throws ClothingException {
        this(Sleeves.SLEEVES_SLEEVELESS);
    }

    @Override
    public Sleeves getSleeves() {
        return sleeves;
    }

    @Override
    public void setSleeves(Sleeves sleeves) {
        this.sleeves = sleeves;
    }

    public ArrayList<String> getCareInfo() {
        return careInfo;
    }

    public void setCareInfo(ArrayList<String> careInfo) {
        this.careInfo = careInfo;
        this.careInfo.add("Hahaha");
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        info += " (TShirt)";
        this.info = info;
    }

    @Override
    public String toString() {
        return super.toString() + "\nTShirt{" +
                "sleeves=" + sleeves +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TShirt)) return false;
        TShirt tShirt = (TShirt) o;
        Clothing clothing = (Clothing) o;
        return super.equals(clothing) && sleeves == tShirt.sleeves;
    }

    @Override
    public int hashCode() {
        return Objects.hash(sleeves);
    }
}
