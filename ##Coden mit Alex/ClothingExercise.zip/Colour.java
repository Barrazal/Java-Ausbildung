public enum Colour {
    COLOUR_WHITE,
    COLOUR_RED,
    COLOUR_BLUE,
    COLOUR_GREEN
}
