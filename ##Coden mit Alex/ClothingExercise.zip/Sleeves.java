public enum Sleeves {
    SLEEVES_LONG,
    SLEEVES_SHORT,
    SLEEVES_SLEEVELESS
}
