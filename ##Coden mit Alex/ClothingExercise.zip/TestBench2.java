import java.util.ArrayList;

public class TestBench2 {
    public static void main(String[] args) {
        ArrayList<Clothing> ourShirts = new ArrayList<>();
        try {
            ourShirts.add(new TShirt(Colour.COLOUR_BLUE, 6, Textile.TEXTILE_COTTON, Sleeves.SLEEVES_LONG));
            ourShirts.get(0).setSleeves(Sleeves.SLEEVES_SHORT);
            ourShirts.add(new TShirt(Colour.COLOUR_WHITE, 5, Textile.TEXTILE_ELASTIC, Sleeves.SLEEVES_SHORT));
            ourShirts.add(new TShirt(Colour.COLOUR_BLUE, 6, Textile.TEXTILE_COTTON, Sleeves.SLEEVES_LONG));
        } catch (ClothingException ex) {
            ex.printStackTrace();
        };

        for (Clothing clothing : ourShirts
             ) {
            System.out.println(clothing);
        }

        System.out.println("We have the same shirt style & size: " + (ourShirts.get(0).equals(ourShirts.get(2))));

        System.out.println(ourShirts.get(0).getSleeves());
    }
}
