import java.util.ArrayList;

public class TestBench {
    public static void main(String[] args) {
        TShirt myShirt = null;
        Clothing myPartnersShirt = null;
        Clothing myFriendsShirt = null;
        Clothing myOtherFriendsBorrowedShirt = null;
        try {
            myShirt = new TShirt(Colour.COLOUR_BLUE, 6, Textile.TEXTILE_COTTON, Sleeves.SLEEVES_LONG);
            myOtherFriendsBorrowedShirt = myShirt;
            myOtherFriendsBorrowedShirt.setSize(7);
            myPartnersShirt = new TShirt(Colour.COLOUR_WHITE, 5, Textile.TEXTILE_ELASTIC, Sleeves.SLEEVES_SHORT);
            myFriendsShirt = new TShirt(Colour.COLOUR_BLUE, 6, Textile.TEXTILE_COTTON, Sleeves.SLEEVES_LONG);
            myFriendsShirt.setSize(7);
        } catch (ClothingException ex) {
            ex.printStackTrace();
        };

        System.out.println(myShirt);
        System.out.println(myPartnersShirt);
        System.out.println(myFriendsShirt);

        // Reference to the Object is passed:
        ArrayList<String> myCareInfo = new ArrayList<>();
        myCareInfo.add("30°");
        myCareInfo.add("handwash");
        myCareInfo.add("no tumbletry");
        myShirt.setCareInfo(myCareInfo);
        System.out.println(myCareInfo);

        // Array - would be also passed as a reference
        int[] myArr = new int[6];

        // Value of the Variable is passed (kind of) (because it is immutable):
        String myInfo = "My special secret!";
        myShirt.setInfo(myInfo);
        System.out.println(myInfo);
        System.out.println(myShirt.getInfo());

        System.out.println("We have the same shirt style & size: " + (myFriendsShirt.equals(myShirt)));
    }
}
