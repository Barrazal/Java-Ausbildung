import java.util.HashMap;

public class ChessBoard {
    private HashMap<Position, ChessFigure> figures;
    public int countFigures;
    private int boardNumber;
    public static int countBoards = 0;

    public ChessBoard() {
        figures = new HashMap<>();
        countFigures = 0;
        countBoards++;
        boardNumber = countBoards;
    }

    boolean removeFigure(Position position) {
        if (figures.containsKey(position)) {
            figures.remove(position);
            countFigures--;
            return true;
        } else {
            return false;
        }
    }

    void registerFigure(ChessFigure figure) {
        figures.put(figure.getPosition(), figure);
        countFigures++;
    }
}
