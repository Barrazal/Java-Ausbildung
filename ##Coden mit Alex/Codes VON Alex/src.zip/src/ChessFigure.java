import java.util.ArrayList;

enum Colour {
    BLACK,
    WHITE
}

enum Type {
    PAWN,
    KING,
    QUEEN,
    BISHOP,
    ROOK,
    KNIGHT
}

enum MoveTypes {
    BISHOP_MOVE,
    KNIGHT_MOVE,
    ROOK_MOVE
}

public abstract class ChessFigure {
    public static int counter = 0;
    private final Colour colour;
    private Position position;
    private final ChessBoard board;

    public ChessFigure(Colour colour, Position position, ChessBoard board) {
        this.colour = colour;
        this.position = position;
        this.board = board;
        this.board.registerFigure(this);
        counter++;
    }

    public Colour getColour() {
        return colour;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public ChessBoard getBoard() {
        return board;
    }

    public abstract Type getType();

    public abstract boolean move(Position newPosition);

    public abstract ArrayList<Position> legalMoves();

    public boolean remove() {
        return board.removeFigure(position);
    }
}
