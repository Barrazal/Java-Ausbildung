import java.util.ArrayList;

public class King extends ChessFigure implements BishopMoves, RookMoves {
    private Boolean isInCheck;
    private final Type type = Type.KING;

    public King(Colour colour, Position position, ChessBoard board) {
        super(colour, position, board);
        this.isInCheck = false;
    }

    @Override
    public Type getType() {
        return type;
    }

    public boolean remove() {
        System.out.println("End of Game");
        return false;
    }

    // Check: King is in danger
    public void setCheck(Boolean check) {
        isInCheck = check;
    }

    public boolean isInCheck() {
        return isInCheck;
    }

    @Override
    public boolean move(Position newPosition) {
        // Cannot move / stay in checked position
        return false;
    }

    @Override
    public ArrayList<Position> legalMoves() {
        return new ArrayList<Position>();
    }

    @Override
    public boolean bishopMove(Position initial, Position destination) {
        return false;
    }

    @Override
    public boolean rookMoves(Position initial, Position destination) {
        return false;
    }
}
