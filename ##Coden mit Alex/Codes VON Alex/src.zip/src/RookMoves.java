public interface RookMoves {
    public boolean rookMoves(Position initial, Position destination);
}
