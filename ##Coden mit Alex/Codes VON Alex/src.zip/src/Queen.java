import java.util.ArrayList;

public class Queen extends ChessFigure {

    private final Type type = Type.QUEEN;

    public Queen(Colour colour, Position position, ChessBoard board) {
        super(colour, position, board);
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public boolean move(Position newPosition) {
        return false;
    }

    @Override
    public ArrayList<Position> legalMoves() {
        return null;
    }
}
