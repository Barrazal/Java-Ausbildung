public interface BishopMoves {
    public boolean bishopMove(Position initial, Position destination);
}
