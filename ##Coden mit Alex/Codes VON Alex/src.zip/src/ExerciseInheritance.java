import java.util.ArrayList;

public class ExerciseInheritance {
    public static void main(String[] args) {
        // Interfaces
        // Typecasting
        // Abstract Classes
        ChessBoard myBoard = new ChessBoard();
        //ChessFigure myFirstTry = new ChessFigure(Colour.BLACK, new Position(4, 1), myBoard);

        ChessFigure blackKing = new King(Colour.BLACK, new Position(4, 1), myBoard);
        RookMoves myFigure = (King) blackKing;
    }
}
