import java.util.ArrayList;

public class Pawn extends ChessFigure {
    private Boolean isPromoted;
    private final Type type = Type.PAWN;

    public Pawn(Colour colour, Position position, ChessBoard board) {
        super(colour, position, board);
        isPromoted = false;
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public boolean move(Position newPosition) {
        return false;
    }

    @Override
    public ArrayList<Position> legalMoves() {
        return null;
    }

    public boolean promote() {
        // Check if pawn is within last enemy line
        return false;
    }
}
